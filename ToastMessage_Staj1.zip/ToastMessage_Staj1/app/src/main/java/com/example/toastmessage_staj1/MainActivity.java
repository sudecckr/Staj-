package com.example.toastmessage_staj1;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText editTextMessage;
    RadioGroup radioGroupDuration;
    Button buttonCustomToast;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextMessage = findViewById(R.id.editTextMessage);
        radioGroupDuration = findViewById(R.id.radioGroupDuration);
        buttonCustomToast = findViewById(R.id.buttonCustomToast);

        buttonCustomToast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showCustomToast();
            }
        });
    }

    private void showCustomToast() {
        String message = editTextMessage.getText().toString().trim();
        if (message.isEmpty()) {
            message = "Merhaba! Bu varsayılan bir mesajdır.";
        }

        int duration = Toast.LENGTH_SHORT;
        if (radioGroupDuration.getCheckedRadioButtonId() == R.id.radioLong) {
            duration = Toast.LENGTH_LONG;
        }

        // Custom Toast Layout
        LayoutInflater inflater = getLayoutInflater();
        View layout = inflater.inflate(R.layout.custom_toast, null);

        TextView text = layout.findViewById(R.id.textCustomToast);
        text.setText(message);

        Toast toast = new Toast(getApplicationContext());
        toast.setDuration(duration);
        toast.setView(layout);
        toast.show();
    }
}
