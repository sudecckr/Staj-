package com.example.kitap;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import com.example.kitap.R;
import com.example.kitap.Book;

public class MainActivity extends AppCompatActivity {

    EditText editTitle, editAuthor, editGenre;
    Button btnAdd;
    RecyclerView recyclerBooks;
    List<Book> bookList = new ArrayList<>();
    com.example.kitap.BookAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTitle = findViewById(R.id.editTitle);
        editAuthor = findViewById(R.id.editAuthor);
        editGenre = findViewById(R.id.editGenre);
        btnAdd = findViewById(R.id.btnAdd);
        recyclerBooks = findViewById(R.id.recyclerBooks);

        adapter = new com.example.kitap.BookAdapter(bookList);
        recyclerBooks.setLayoutManager(new LinearLayoutManager(this));
        recyclerBooks.setAdapter(adapter);

        btnAdd.setOnClickListener(v -> {
            String title = editTitle.getText().toString();
            String author = editAuthor.getText().toString();
            String genre = editGenre.getText().toString();

            if (!title.isEmpty() && !author.isEmpty() && !genre.isEmpty()) {
                bookList.add(new Book(title, author, genre));
                adapter.notifyItemInserted(bookList.size() - 1);

                editTitle.setText("");
                editAuthor.setText("");
                editGenre.setText("");
            }
        });
    }
}
