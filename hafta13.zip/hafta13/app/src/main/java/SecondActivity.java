package com.example.hafta13;


import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.content.SharedPreferences;
import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {

    TextView txtName, txtAge, txtEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        txtName = findViewById(R.id.txtName);
        txtAge = findViewById(R.id.txtAge);
        txtEmail = findViewById(R.id.txtEmail);

        // SharedPreferences'ten veriyi çek
        SharedPreferences prefs = getSharedPreferences("userData", MODE_PRIVATE);
        String name = prefs.getString("name", "Ad yok");
        String age = prefs.getString("age", "Yaş yok");
        String email = prefs.getString("email", "E-posta yok");

        // TextView'lara veriyi yazdır
        txtName.setText("Ad: " + name);
        txtAge.setText("Yaş: " + age);
        txtEmail.setText("E-posta: " + email);
    }
}
