package com.example.hafta13;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.content.Intent;
import android.content.SharedPreferences;





public class MainActivity extends AppCompatActivity {

    EditText edtName, edtAge, edtEmail;
    Button btnSave;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtName = findViewById(R.id.edtName);
        edtAge = findViewById(R.id.edtAge);
        edtEmail = findViewById(R.id.edtEmail);
        btnSave = findViewById(R.id.btnSave);

        btnSave.setOnClickListener(v -> {
            String name = edtName.getText().toString();
            String age = edtAge.getText().toString();
            String email = edtEmail.getText().toString();

            SharedPreferences prefs = getSharedPreferences("userData", MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();
            editor.putString("name", name);
            editor.putString("age", age);
            editor.putString("email", email);
            editor.apply();

            Intent intent = new Intent(MainActivity.this, com.example.hafta13.SecondActivity.class);
            startActivity(intent);
        });
    }
}
