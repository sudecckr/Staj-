package com.example.activityintent1;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {

    TextView textMesaj;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        textMesaj = findViewById(R.id.textMesaj);


        String ad = getIntent().getStringExtra("kullaniciAdi");


        textMesaj.setText("Hoş geldin, " + ad + "!");
    }
}
