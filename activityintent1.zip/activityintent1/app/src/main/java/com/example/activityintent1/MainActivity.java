package com.example.activityintent1;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText editAd;
    Button btnDevam;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editAd = findViewById(R.id.editAd);
        btnDevam = findViewById(R.id.btnDevam);

        btnDevam.setOnClickListener(v -> {
            String ad = editAd.getText().toString();
            Intent intent = new Intent(MainActivity.this, SecondActivity.class);
            intent.putExtra("kullaniciAdi", ad);
            startActivity(intent);
        });
    }
}
